Homework 2 Part 1:
    For "homework2_twgoon.py" to work correctly the file structure must be maintained in the following format:
    homework2_twgoon.py
    data/
        testing/
            age_regression_Xte.npy
            age_regression_yte.npy
        training/
            age_regression_Xtr.npy
            age_regression_ytr.npy